<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>간단 로그인</title>
</head>
<body>
<form name="addr" action="control.jsp" method="post">
	아이디: <input type="text" name="id" />
	패스워드: <input type="text" name="passwd" />
	<input type="submit" value="로그인" />
</form>
</body>
</html>