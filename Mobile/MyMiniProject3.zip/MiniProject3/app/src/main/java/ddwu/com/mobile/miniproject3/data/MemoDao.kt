package ddwu.com.mobile.miniproject3.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/*Memo Dao 구현*/
@Dao
interface MemoDao {
    @Insert
    suspend fun insertMemo(vararg  memo: Memo)

    @Update
    suspend fun updateMemo(memo: Memo)

    @Delete
    fun deleteMemo(memo: Memo)

    @Query("SELECT * FROM memo_table")
    fun getAllMemos(): Flow<List<Memo>>

//    @Query("SELECT * FROM memo_table WHERE title")
//    suspend fun getMemoByTitle(title: String): Memo
}