package ddwu.com.mobile.miniproject3

import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
//import com.bumptech.glide.Glide
import ddwu.com.mobile.miniproject3.data.Memo
import ddwu.com.mobile.miniproject3.data.MemoDatabase
import ddwu.com.mobile.miniproject3.databinding.ActivityMemoDetailBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import kotlin.getValue

class MemoDetailActivity : AppCompatActivity() {

    val binding by lazy { ActivityMemoDetailBinding.inflate(layoutInflater) }
    val memoDao by lazy {
        MemoDatabase.getInstance(this).getMemoDao()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val memo = intent.getSerializableExtra("memo_data") as Memo

        binding.etTitle.setText(memo.title)
        binding.etContents.setText(memo.content)

        val uri = memo.imagePath
        if (uri != null) {
            Glide.with(this)
                .load(uri)
                .into(binding.imageViewPicked)
        } else {
            binding.imageViewPicked.setImageResource(android.R.drawable.ic_menu_info_details)
        }

        binding.imageViewPicked.setOnClickListener {

        }

        binding.btnUpdate.setOnClickListener {
            val newMemo = Memo(0, binding.etTitle.text.toString(), binding.etContents.text.toString(), uri)
            CoroutineScope(Dispatchers.IO).launch {
                memoDao.insertMemo(newMemo)
            }

            finish()
        }


        binding.btnCancel.setOnClickListener {
            try {
                val isRemoved = FileUtil.deleteFile(uri)
                if (isRemoved) {
                    Glide.with(this) // 기본 사진으로 변경
                        .load(android.R.drawable.ic_menu_camera) // Android 기본 icon 사용
                        .into(binding.imageViewPicked)
                }
            } catch (e: IOException) {
                Log.e("TAG", "이미지 삭제 오류", e)
            }

            finish()
        }
    }
}